#include <Windows.h>
#include <vector>
#include "Component.h"

class FAT32 {
private:
	LPCWSTR _drive;
    BYTE* BootSector;
    BYTE* FAT;
    std::vector<Component> componentList;

    unsigned int bytes_sector;
    unsigned int sectors_cluster;
    unsigned int sectors_bootsector;
    unsigned int FAT_tables;
    unsigned int volume_size;
    unsigned int FAT_size;
    unsigned int first_cluster_RDET;
public:
    FAT32();
    FAT32(LPCWSTR drive);
    ~FAT32();
public:
    void Print_BootSector_Info();
    void Read_RDET();
    void Read_SDET(unsigned int first_cluster, unsigned int last_cluster, int level);
    void Print_RDET();
    void Print_FolderTree();
    std::string Read_Data();
    void Print_Data();
};
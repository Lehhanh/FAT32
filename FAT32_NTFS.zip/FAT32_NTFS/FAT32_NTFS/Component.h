#pragma once
#include <string>

class Component {
private:
	std::string _name;
	unsigned int _status;
	unsigned int _firstCluster;
	unsigned int _lastCluster;
	unsigned int _level;
	unsigned int _size;
public:
	Component();
	Component(std::string name, unsigned int status, unsigned int firstCluster, unsigned int lastCluster, unsigned int level, unsigned int size);
public:
	std::string name();
	unsigned int status();
	unsigned int firstCluster();
	unsigned int lastCluster();
	unsigned int level();
	unsigned int size();
};